void print_arr(double *g, int nrow, int ncol) ;

void print_grid(double **g, int nrow, int ncol) ;

double **calloc_matrix(int nrow, int ncol);

void initBoundary(double **g, int nrow);

void radiator(int iter, int nrow, int ncol, double **A, double **B, double **t);

void avgRow(double **g, double *avg, int nrow, int ncol) ;

//void swap(double **a, double **b, double **s);

void compareValues(double **g, double *arr,int nrow, int ncol, double eps);



