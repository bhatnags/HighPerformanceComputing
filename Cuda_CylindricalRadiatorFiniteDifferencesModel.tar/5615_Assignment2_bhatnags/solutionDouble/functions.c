#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include "functions.h"
#include <math.h>


void print_arr(double *g, int nrow, int ncol) {
	printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
	int i;
	
	for(i = 0; i<nrow*ncol; i++){
		printf("%2.6f\t", g[i]);
	  if(i%ncol == ncol-1){	printf("\n");	}
	}
}

void print_grid(double **g, int nrow, int ncol) {
	printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
	int i, j;
	for(i=0;i<nrow;i++) {
		for(j=0;j<ncol;j++){
			printf("%2.6f\t", g[i][j]);
		}
		printf("\n");
	}
}

double **calloc_matrix(int nrow, int ncol){
	double **g, *tmp;
	int i;
	g = calloc(sizeof(double *), nrow);//allocates a doubleing point matrix of size n x m
	tmp = calloc(sizeof(double), nrow*ncol);
	for(i=0;i<nrow;i++) {
		g[i] = &tmp[ncol*i];
	}
return g;
}


void initBoundary(double **g, int nrow){
	int i;
	for(i=0;i<nrow;i++) {
		g[i][0] = 0.85*(double)((i+1)*(i+1))/(double)(nrow*nrow);// (so the values range between 0.85/(double)(n*n) and 0.85)
		g[i][1] = 1.00*(double)((i+1)*(i+1))/(double)(nrow*nrow);// (so the values range between 1.00/(double)(n*n) and 1.00)
	}
}

void radiator(int iter, int nrow, int ncol, double **A, double **B, double **t){
	int i, j, count;
	for(count =0; count< iter; count++){
	//Update B from values in A
		
		for(i=0; i< nrow; i++){
		for(j=2; j< ncol; j++){
			if(j==(ncol-2)){
			B[i][j]= ( 	(0.15*(A[i][j-2]))+
					(0.65*(A[i][j-1]))+ 
					(A[i][j])+ 
					(1.35*(A[i][j+1]))+
					(1.85*(A[i][0])) ); 
				
			}else if(j==(ncol-1)){
			B[i][j]= ( 	(0.15*(A[i][j-2]))+
					(0.65*(A[i][j-1]))+ 
					(A[i][j])+ 
					(1.35*(A[i][0]))+
					(1.85*(A[i][1])) ); 

			}else{
			B[i][j]= ( 	(0.15*(A[i][j-2]))+
					(0.65*(A[i][j-1]))+ 
					(A[i][j])+ 
					(1.35*(A[i][j+1]))+
					(1.85*(A[i][j+2])) ); 
			}
			B[i][j]/=(double)(5.0);
		}
		}
	t=A;A=B;B=t;//Swapping
//	print_grid(A, nrow,ncol);
	}
}

void avgRow(double **g, double *avg, int nrow, int ncol) {
	int i, j, k;
	for(k=0; k<nrow; k++){
		avg[k]=0.0;
	}
	for(i=0;i<nrow;i++) {
	  double sum = 0.0;
	  for(j=0;j<ncol;j++){
		sum += g[i][j];
	  }
	  avg[i]=sum/ncol;
	}
}


void compareValues(double **g, double *arr,int nrow, int ncol, double eps){
    int count = 0;
    int j = 0;
    int i = 0;
    do{
    if(abs(g[i][j]-arr[i])>eps){
	  printf("Diff of values at position (%d, %d) is greater than permitted\n", i, j);
	  count++;
    }
    if(j<ncol-1){j++;}else{j=0;}
    if(j == ncol-1){i++;}
    }while(i<nrow && j<ncol);
    if(count == 0){
	printf("Values from CPU and GPU match with error less than eps\n");
    }
}

