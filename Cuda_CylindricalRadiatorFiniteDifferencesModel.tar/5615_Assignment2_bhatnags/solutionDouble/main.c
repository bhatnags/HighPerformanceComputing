//=============================================================================================
// Name        		: main.c
// Author      		: Saumya Bhatnagar
// Creation date	:	17-03-2018
// Copyright		: No Copyrights
// Description		: Cylindrical Heat Radiator! The following is expected out of this program
//
//===========================CPU==========================================
//allocate 2 doubleing point matrices of size n x m (default n =m = 32), by passing CL args
//boundary conditions for column 0 and 1 is calculated, to remain constant, rest all columns are initialized to zero
//Heat propagation iterations are given by CL args -p (default p = 10)
//cyclic heat propagation in rows, water flows left, heat moves right
//heat prop conditions are applied as given
//circular heat propagation conditions are applied
//CL arg -a to calculate avergage temperature of each row
//============================GPU========================================
//start with block size = 5 for debuging
//use n=m=32 for computations
//use atomic/shared/texture/surface memory
//no library other than CUDA
//check cudaEvents, atomic, sharedMemory, for reference
//copy back results in RAM, compare with CPU results
//compare with CPU results, time and values (for values => epsilon = 10^-5)
//time steps:
//	compute on CPU
//	allocate on GPU
//	transfer to GPU
//	compute on GPU
//	calculation of averages
//	transfer back to RAM
//CL args -t to display time taken
//=======================Performance Improvement===============================
//test for n = m = 15360, p=1000, 
//speedups expected >6 < 60
//different threads per block, different numbers in each x and y directions
//speedups and precision comparison of CPU and GPU
//reduce vector comparison, with assignment 1
//==============================================================================
//=============================================================================================
//introduce -G in NVCC flags

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include "functions.h"

extern void computeGPU(double *data, int N, int M, int iter, int dTime);
extern void getRowAvgGPU(double *g, double *avg, int N, int M, int dTime);
extern void findDevices();

double eps=0.00001;
int ROW = 32;
int COL = 32;
int ITER = 4;
int getGridPrint = 0;
int getAvgTemp = 0;
int displayTime = 1;
int graphTime = 0;
 
void parse_args(int argc, char *argv[]){
	if(argc<5){
		printf("Please give the number of rows and columns\n");
		exit(1);
	}
	char option;
	while((option = getopt(argc, argv, "nmpagtr")) != -1){
		if(option == '?'){
			printf("ERROR: unknown flag!\n");
			exit(1);			
		}
		switch(option){
		case 'n': //number of rows
			ROW = atoi(argv[optind]);
			break;
		case 'm': //number of columns
			COL = atoi(argv[optind]);
			break;
		case 'p': //number fo iterations
			ITER = atoi(argv[optind]);
			break;
		case 'a': //get average temperature of the rows
			getAvgTemp = atoi(argv[optind]);
			break;
		case 'g': //print the grid, type 1 for printing
			getGridPrint = atoi(argv[optind]);
			break;
		case 't': //display timings by each function, displayed by default
			displayTime = atoi(argv[optind]);
			break;
		case 'r': //display timings by each function, displayed by default`
			graphTime = atoi(argv[optind]);
			break;
		default:
			break;
		}
	}
	if(graphTime==0){
	  printf("\nCL format: \n\t./prog -n -m -p -a -g -t, for number of rows, columns, iterations, \n\tget avg temp of each row(1 or 0), get the grid printed(1 or 0), \n\tget the timings(1 or 0), get the graph timings\n\n");
	}
}

int main(int argc, char *argv[]){
	parse_args(argc, argv);
	if(graphTime==0){
	  findDevices();
	}
	double **A, **B, **t;
	
	struct timeval t1_start, t1_end, t2_start, t2_end, t3_start, t3_end, t4_start, t4_end, cpuStart, cpuEnd, gpuStart, gpuEnd;
	double t1, t2, t3, t4, cpuT, gpuT;
	
	/**************************************************************************************************/	
	/*****************************Get CPU timings & SUMs**************************************/
	/***********************************************************************************/	
	
	gettimeofday(&cpuStart, NULL);
	/**__________________________ Allocate matrix, time taken = t1__________________________________**/
	gettimeofday(&t1_start, NULL);
	A = calloc_matrix(ROW, COL);//allocates a doubleing point matrix of size n x m
	B = calloc_matrix(ROW, COL);//allocates a doubleing point matrix of size n x m
	t = calloc_matrix(ROW, COL);//allocates a doubleing point matrix of size n x m
	gettimeofday(&t1_end, NULL);
	t1 = (t1_end.tv_sec - t1_start.tv_sec) * 1000000 + (t1_end.tv_usec - t1_start.tv_usec);
	
	/***______________________________Inialize matrix, time taken = t2________________________________**/
	gettimeofday(&t2_start, NULL);
	initBoundary(A, ROW);
	initBoundary(B, ROW);
	gettimeofday(&t2_end, NULL);
	t2= (t2_end.tv_sec - t2_start.tv_sec) * 1000000 + (t2_end.tv_usec - t2_start.tv_usec);

	if(getGridPrint == 1){
	  printf("Grid A\n");
	  print_grid(A, ROW, COL);
	}

	/**_______________________Start the radiator, time taken = t3______________________________________**/
	gettimeofday(&t3_start, NULL);
	radiator(ITER,ROW, COL, A, B, t);
	gettimeofday(&t3_end, NULL);
	t3 = (t3_end.tv_sec - t3_start.tv_sec) * 1000000 + (t3_end.tv_usec - t3_start.tv_usec);

	gettimeofday(&cpuEnd, NULL);
	cpuT = (cpuEnd.tv_sec - cpuStart.tv_sec) * 1000000 + (cpuEnd.tv_usec - cpuStart.tv_usec);
	if(getGridPrint == 1){
	  printf("~~~~~~~~~~~~Heat radiation done~~~~~~~~~~~~~~~~~~~~\n");
	  printf("Grid A after CPU computations\n");
	  print_grid(A, ROW, COL);
	}
	/**_________________Get the averages for every row, time taken = t4__________________________**/
	double *avg;
	avg = calloc(sizeof(double), ROW);
	gettimeofday(&t4_start, NULL);
	avgRow(A, avg, ROW, COL) ;
	if(getAvgTemp == 1){
	  printf("Average of Grid A rows\n");
	  print_arr(avg, ROW, 1);
	}
	
	gettimeofday(&t4_end, NULL);
	t4 = (t4_end.tv_sec - t4_start.tv_sec) * 1000000 + (t4_end.tv_usec - t4_start.tv_usec);

	if(displayTime){
	  printf("\nCPU timings:\n\tTime taken in allocating grid=%3.3f,\n\tTime taken in Initializing the grid=%3.3f,\n\tTime taken by RADIATOR=%3.3f,\n\tTime taken to get the average of each row=%3.3f\n", t1, t2, t3,t4);
	}

	/******************************************************************************************/	
	/**********************************Get GPU timings & SUMs*******************************************/
	/***************************************************************************************************/	
	
	gettimeofday(&gpuStart, NULL);
	double *data;
	data = calloc(sizeof(double), ROW*COL);//allocates a doubleing point array of size n x m
	double *gpuAvg;
	gpuAvg = calloc(sizeof(double), ROW);//allocates a doubleing point array of size n x m
	computeGPU(data, ROW, COL, ITER, displayTime);
	gettimeofday(&gpuEnd, NULL);
	gpuT = (gpuEnd.tv_sec - gpuStart.tv_sec) * 1000000 + (gpuEnd.tv_usec - gpuStart.tv_usec);
	if(getGridPrint == 1){
	  printf("Grid A after GPU computations\n");
	  print_arr(data, ROW, COL);
	}
	if(getAvgTemp == 1){
	  getRowAvgGPU(data, gpuAvg, ROW, COL, displayTime);
	  printf("GPU Average of Grid A rows\n");
	  print_arr(gpuAvg, ROW, 1);
	}

	/*************Cmpare Values from GPU with CPU***************/
	if(graphTime == 0){
	  compareValues(A, data, ROW, COL, eps);
	}
	if(graphTime == 1){
	  printf("%d\t%d\t%3.3f\t%3.3f\n", ROW, ITER, cpuT, gpuT);
	}
 

	exit(0);
}
