void print_arr(float *g, int nrow, int ncol) ;

void print_grid(float **g, int nrow, int ncol) ;

float **calloc_matrix(int nrow, int ncol);

void initBoundary(float **g, int nrow);

void radiator(int iter, int nrow, int ncol, float **A, float **B, float **t);

void avgRow(float **g, float *avg, int nrow, int ncol) ;

//void swap(float **a, float **b, float **s);

void compareValues(float **g, float *arr,int nrow, int ncol, float eps);



