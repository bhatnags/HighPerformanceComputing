#!/bin/bash

#SBATCH -n 8
#SBATCH -p compute
#SBATCH -t 3-15:00:00
#SBATCH -J my_hpl_job_1_node

# source the module commands
source /etc/profile.d/modules.sh

# load the modules used to build the xhpl binary
module load default-gcc-openmpi
# module load default-intel-openmpi
module load libs mkl/64/11.0.074
module load libs acml/64/gfortran/4.3.0
# module load opnempi/1.6.5-gnu4.8.2

cd ./bin/lonsdale_intel11_openmpi186_acml430

# run it
mpirun -np 8 ./xhpl 


