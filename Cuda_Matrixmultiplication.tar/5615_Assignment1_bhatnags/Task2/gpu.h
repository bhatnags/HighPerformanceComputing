//Calling cuda functions
extern void d_addRows(float **g, float *vec, int nrow, int ncol, int block_size);
extern void d_addCols(float **g, float *vec, int nrow, int ncol, int block_size);
/*extern void d_addRows_reduce(float **g, float *sum_r, int nrow, int ncol, int block_size);
extern void d_addCols_reduce(float **g, float *sum_c, int nrow, int ncol, int block_size);

*/


