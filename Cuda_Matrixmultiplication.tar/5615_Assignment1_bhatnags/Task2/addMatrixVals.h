void print_grid(float **g, int nrow, int ncol);
float *addRows(float **g, int nrow, int ncol);
float *addCols(float **g, int nrow, int ncol);
float addReduceVec(float *vec, int num);
void compareValues_r(float *row_vec, float *sum_row, int nrow, float eps);
void compareValues_c(float *col_vec, float *sum_col, int ncol, float eps);
