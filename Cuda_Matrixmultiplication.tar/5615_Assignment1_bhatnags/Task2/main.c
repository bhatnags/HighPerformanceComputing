//=============================================================================================
// Name        		: main.c
// Author      		: Saumya Bhatnagar
// Version     		:	25-02-2018
// Creation date	:	17-02-2018
// Copyright		: No Copyrights
// Description		: This program will sum the rows and columns of a matrix of size n x m. 
//						Also, will sum the complete matrix to a single value using either the row sum or column sum
//=============================================================================================

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include "addMatrixVals.h"
#include "gpu.h"

float eps=0.0005;


int ROW = 10;
int COL = 10;
int SEED = 123456; 
int timeDisplay = 0;
int block_size =18;
//char DATA_TYPE[256];

float *row_vec, *col_vec, *sum_row, *sum_col, *sum_r, *sum_c;

void parse_args(int argc, char *argv[]){
	char option;
	while((option = getopt(argc, argv, "nmrtbd")) != -1){
		if(option == '?'){
			printf("ERROR: unknown flag!\n");
			exit(1);			
		}
		switch(option){
		case 'n': //number of rows
			ROW = atoi(argv[optind]);
			break;
		case 'm': //number of columns
			COL = atoi(argv[optind]);
			break;
		case 'r': //to seed the number of milliseconds
			SEED = atoi(argv[optind]);
			break;
		case 't': //to display the timings
			timeDisplay = 1;
			break;
		case 'b': //to display the timings
			block_size = atoi(argv[optind]);
			break;
//		case 'd':
//			DATA_TYPE = 'double';
//			break;
		default:
			break;
		}
	}
}


int main(int argc, char *argv[]){
	parse_args(argc, argv);
	srand48(SEED);

	float **g;
	float *tmp;
	int i, j;
	g = calloc(sizeof(float *), ROW);//allocates a floating point matrix of size n x m
	tmp = calloc(sizeof(float), ROW*COL);
	for(i=0;i<ROW;i++) {
		g[i] = &tmp[COL*i];
	}
	for(i=0;i<ROW;i++) {
		for(j=0;j<COL;j++){
			g[i][j] = (float)(drand48());//each element is initialized by calling (float)(drand48())
		}
	}
//	print_grid(g, ROW, COL);
	struct timeval t1_start, t1_end, t2_start, t2_end, t3_start, t3_end, t4_start, t4_end, t5_start, t5_end, t6_start, t6_end;//, t7_start, t7_end, t8_start, t8_end;

	/******************************************TIMINGS & SUM COMPUTATIONS*********************************************/
	/*****************************************Get CPU timings & SUMs*********************************************************/
	gettimeofday(&t2_start, NULL);
	col_vec = addCols(g, ROW, COL);
	gettimeofday(&t2_end, NULL);
	long long t2_time = (t2_end.tv_sec - t2_start.tv_sec) * 1000000L + (t2_end.tv_usec - t2_start.tv_usec);

	gettimeofday(&t4_start, NULL);
//	float col_vec_sum = 
	addReduceVec(col_vec, ROW);
	gettimeofday(&t4_end, NULL);
	long long t4_time = (t4_end.tv_sec - t4_start.tv_sec) * 1000000L + (t4_end.tv_usec - t4_start.tv_usec);

	
	gettimeofday(&t1_start, NULL);
	row_vec = addRows(g, ROW, COL);
	gettimeofday(&t1_end, NULL);
	long long t1_time = (t1_end.tv_sec - t1_start.tv_sec) * 1000000L + (t1_end.tv_usec - t1_start.tv_usec);

	gettimeofday(&t3_start, NULL);
//	float row_vec_sum = 
	addReduceVec(row_vec, ROW);
	gettimeofday(&t3_end, NULL);
	long long t3_time = (t3_end.tv_sec - t3_start.tv_sec) * 1000000L + (t3_end.tv_usec - t3_start.tv_usec);

//	printf("row sum = %f\n", row_vec_sum);
//	printf("col sum = %f\n", col_vec_sum);
	
	/*****************************************Get GPU timings & SUMs*********************************************************/
	gettimeofday(&t5_start, NULL);
	d_addRows(g, sum_row, ROW, COL, block_size);
	gettimeofday(&t5_end, NULL);
	long long t5_time = (t5_end.tv_sec - t5_start.tv_sec) * 1000000L + (t5_end.tv_usec - t5_start.tv_usec);

	gettimeofday(&t6_start, NULL);
	d_addCols(g, sum_col, ROW, COL, block_size);
	gettimeofday(&t6_end, NULL);
	long long t6_time = (t6_end.tv_sec - t6_start.tv_sec) * 1000000L + (t6_end.tv_usec - t6_start.tv_usec);

/*
	gettimeofday(&t7_start, NULL);
	d_addRows_reduce(g, sum_r, ROW, COL, block_size);
	gettimeofday(&t7_end, NULL);
	long long t7_time = (t7_end.tv_sec - t7_start.tv_sec) * 1000000L + (t7_end.tv_usec - t7_start.tv_usec);

	gettimeofday(&t8_start, NULL);
	d_addCols_reduce(g, sum_c, ROW, COL, block_size);
	gettimeofday(&t8_end, NULL);
	long long t8_time = (t8_end.tv_sec - t8_start.tv_sec) * 1000000L + (t8_end.tv_usec - t8_start.tv_usec);
*/

	/********************************************Display Timings***************************************************/
	if(timeDisplay){
		printf("~~~~~~~~~~~~~~~~~~~~~~~CPU TIMINGS~~~~~~~~~~~~~~~~~~~~~~~~~~~`\n");
		printf("Row summing took %lld microseconds\n", t1_time);
		printf("Col summing took %lld microseconds\n", t2_time);
		printf("Row vector reducing took %lld microseconds\n", t3_time);
		printf("Col vector reducing took %lld microseconds\n", t4_time);
		printf("~~~~~~~~~~~~~~~~~~~~~~~GPU TIMINGS~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		printf("GPU Row summing took %lld microseconds\n", t5_time);
		printf("GPU Col summing took %lld microseconds\n", t6_time);
//		printf("GPU Row vector reducing took %lld microseconds\n", t7_time);
//		printf("GPU Col vector reducing took %lld microseconds\n", t8_time);
	}

	/*********************************************Display Comparisons**************************************************/
	printf("Compare CPU sum and GPU sum values\n");
	/*****************************Comparisons of GPU and CPU summation values of the grid**************************************************/
	compareValues_r(row_vec, sum_row, ROW, eps);
	compareValues_c(col_vec, sum_col, COL, eps);
	exit(0);
}
