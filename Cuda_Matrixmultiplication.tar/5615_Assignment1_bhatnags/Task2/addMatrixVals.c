#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include "addMatrixVals.h"
#include <math.h>



void print_grid(float **g, int nrow, int ncol) {
	int i, j;
	for(i=0;i<nrow;i++) {
		for(j=0;j<ncol;j++){
			printf("%2.2f\t", g[i][j]);
		}
		printf("\n");
	}
}

float *addRows(float **g, int nrow, int ncol){
	float *rowVec = (float *)calloc(sizeof(float), nrow); //allocate memory and initialize to zero
	int i, j;
	for(i = 0; i < nrow; i++){
		float sum_row = 0.0;
		for(j = 0; j < ncol; j++){
			sum_row += g[i][j];
		}
		rowVec[i] = sum_row;
	}
	return rowVec;
}

float *addCols(float **g, int nrow, int ncol){
	float *colVec = (float *)calloc(sizeof(float), ncol); //allocate memory and initialize to zero
	int i, j;
	for(j = 0; j < ncol; j++){
		float sum_col = 0.0;
		for(i = 0; i < nrow; i++){
			sum_col += g[i][j];
		}
		colVec[j] = sum_col;
	}
	return colVec;
}

float addReduceVec(float *vec, int num){
	float sum_T = 0.0;
	int i;
	for(i = 0; i < num; i++){
		sum_T += vec[i];
	}
	return sum_T;
}

void compareValues_r(float *row_vec,float *sum_row,int nrow, float eps){
	int check = 0;
	while(check < nrow){
		if(abs(row_vec[check] - sum_row[check])< eps){
			printf("Diff between sum rows by CPU and GPU is less than %2.2f", eps);
		}else{
			printf("Diff between sum rows by CPU and GPU is more than %2.2f", eps);
		}
	}
	check++;
}

void compareValues_c(float *col_vec, float *sum_col, int ncol, float eps){
//	int check = 0;
	for(int check = 0; check < ncol; check++){
		if(abs(col_vec[check] - sum_col[check])< eps){
			printf("Diff between sum cols by CPU and GPU is less than %2.2f", eps);
		}else{
			printf("Diff between sum cols by CPU and GPU is more than %2.2f", eps);
		}
	}
}



