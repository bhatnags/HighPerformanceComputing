void print_grid(double **g, int ROW, int COL);
float *addRows(float **g, int nrow, int ncol);
float *addCols(float **g, int nrow, int ncol);
float addReduceVec(float *vec, int num);
