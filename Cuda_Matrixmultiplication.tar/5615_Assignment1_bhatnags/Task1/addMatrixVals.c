#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include "addMatrixVals.h"

void print_grid(float **g, int nrow, int ncol) {//Print the grid
	int i, j;
	for(i=0;i<nrow;i++) {
		for(j=0;j<ncol;j++){
			printf("%2.2f\t", g[i][j]);
		}
		printf("\n");
	}
}

float *addRows(float **g, int nrow, int ncol){//add all the values in the row
	float *rowVec = (float *)calloc(sizeof(float), nrow); //allocate memory and initialize to zero
	int i, j;
	for(i = 0; i < nrow; i++){
		float sum_row = 0.0;
		for(j = 0; j < ncol; j++){
			sum_row += g[i][j];
		}
		rowVec[i] = sum_row;
	}
	return rowVec;
}

float *addCols(float **g, int nrow, int ncol){//add all the values in the col
	float *colVec = (float *)calloc(sizeof(float), ncol); //allocate memory and initialize to zero
	int i, j;
	for(j = 0; j < ncol; j++){
		float sum_col = 0.0;
		for(i = 0; i < nrow; i++){
			sum_col += g[i][j];
		}
		colVec[i] = sum_col;
	}
	return colVec;
}

float addReduceVec(float *vec, int num){
	float sum_T = 0.0;
	int i;
	for(i = 0; i < num; i++){
		sum_T += vec[i];
	}
	return sum_T;
}
