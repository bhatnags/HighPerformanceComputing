//=============================================================================================
// Name        		: main.c
// Author      		: Saumya Bhatnagar
// Version     		:	19-02-2018
// Creation date	:	15-02-2018
// Copyright		: No Copyrights
// Description		: This program will sum the rows and columns of a matrix of size n x m. 
//						Also, will sum the complete matrix to a single value using either the row sum or column sum
//=============================================================================================


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include "addMatrixVals.h"

int ROW = 10;
int COL = 10;
int SEED = 123456; 
int timeDisplay = 0;

void parse_args(int argc, char *argv[]){
	char option;
	while((option = getopt(argc, argv, "nmrt")) != -1){
		if(option == '?'){
			printf("ERROR: unknown flag!\n");
			exit(1);			
		}
		switch(option){
		case 'n': //number of rows
			ROW = atoi(argv[optind]);
			break;
		case 'm': //number of columns
			COL = atoi(argv[optind]);
			break;
		case 'r': //to seed the number of milliseconds
			SEED = atoi(argv[optind]);
			break;
		case 't': //to display the timings
			timeDisplay = 1;
			break;
		default:
			break;
		}
	}
}

int main(int argc, char *argv[]){
	parse_args(argc, argv);
	srand48(SEED);

	float **g;
	float *tmp;
	int i, j;
	g = calloc(sizeof(float *),ROW);//allocates a floating point matrix of size n x m
	tmp = calloc(sizeof(float), ROW*COL);
	for(i=0;i<ROW;i++) {
		g[i] = &tmp[COL*i];
	}

	for(i=0;i<ROW;i++) {
		for(j=0;j<COL;j++){
			g[i][j] = (float)(drand48());//each element is initialized by calling (float)(drand48())
		}
	}

//	print_grid(g, ROW, COL);

	struct timeval t1_start, t1_end, t2_start, t2_end, t3_start, t3_end, t4_start, t4_end;

	gettimeofday(&t1_start, NULL);
	float *row_vec = addRows(g, ROW, COL);
	gettimeofday(&t1_end, NULL);
	float t1_time = (t1_end.tv_sec - t1_start.tv_sec) * 1000000L + (t1_end.tv_usec - t1_start.tv_usec);

	gettimeofday(&t2_start, NULL);
	float *col_vec = addCols(g, ROW, COL);
	gettimeofday(&t2_end, NULL);
	float t2_time = (t2_end.tv_sec - t2_start.tv_sec) * 1000000L + (t2_end.tv_usec - t2_start.tv_usec);

	gettimeofday(&t3_start, NULL);
	//float row_vec_sum = 
	addReduceVec(row_vec, ROW);
	gettimeofday(&t3_end, NULL);
	float t3_time = (t3_end.tv_sec - t3_start.tv_sec) * 1000000L + (t3_end.tv_usec - t3_start.tv_usec);

	gettimeofday(&t4_start, NULL);
	//float col_vec_sum = 
	addReduceVec(col_vec, COL);
	gettimeofday(&t4_end, NULL);
	float t4_time = (t4_end.tv_sec - t4_start.tv_sec) * 1000000L + (t4_end.tv_usec - t4_start.tv_usec);

	if(timeDisplay){
		printf("Row summing took %f microseconds\n", t1_time);
		printf("Col summing took %f microseconds\n", t2_time);
		printf("Row vector reducing took %f microseconds\n", t3_time);
		printf("Col vector reducing took %f microseconds\n", t4_time);
	}

	exit(0);
}
