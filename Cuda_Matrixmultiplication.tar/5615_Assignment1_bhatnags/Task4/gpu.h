//Calling cuda functions
extern void d_addRows(double **g, double *vec, int nrow, int ncol, int block_size);
extern void d_addCols(double **g, double *vec, int nrow, int ncol, int block_size);
/*extern void d_addRows_reduce(double **g, double *sum_r, int nrow, int ncol, int block_size);
extern void d_addCols_reduce(double **g, double *sum_c, int nrow, int ncol, int block_size);

*/


