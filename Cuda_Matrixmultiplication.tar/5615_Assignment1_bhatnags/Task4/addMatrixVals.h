void print_grid(double **g, int nrow, int ncol);
double *addRows(double **g, int nrow, int ncol);
double *addCols(double **g, int nrow, int ncol);
double addReduceVec(double *vec, int num);
void compareValues_r(double *row_vec, double *sum_row, int nrow, double eps);
void compareValues_c(double *col_vec, double *sum_col, int ncol, double eps);
