// Source : cuda_source_code_01


#ifdef __cplusplus
extern "C" {

	float gpuAllocateFloat(int n, int ns, float **arr);
	float transferToRamFloat(int n, int ns, float **d_arr, float **h_arr);
	float getResultsFloat(float *arr, int n, int ns, float a, float division, int maxIterations, int K);
	float getResultsFloatStream(float **h_arr, int n, int ns, float a, float division, int maxIterations, int K);	

	float gpuAllocateDouble(int n, int ns, double **arr);
	float transferToRamDouble(int n, int ns, double **d_arr, double **h_arr);
	float getResultsDouble(double *arr, int n, int ns, double a, double division, int maxIterations, int K);
	float getResultsDoubleStream(double **h_arr, int n, int ns, double a, double division, int maxIterations, int K);	

	void freeFloat(float **arr);
	void findDevices();

}
#endif
